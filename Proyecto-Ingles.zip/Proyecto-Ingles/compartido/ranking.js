/* ============================================================
   ranking.js
   Ranking por dificultad (Easy / Medium / Hard): muestra el mejor
   puntaje de cada usuario leyendo los mismos registros hist_<usuario>
   que usa "Ver mi historial". Los datos de ejemplo se siembran en
   historial-ejemplo.js, sin botones ni controles adicionales.
   ============================================================ */

  const NIVELES_RANKING = [
    { id: 'facil',   nombre: 'Easy',   emoji: '🟢', color: '#58CC02' },
    { id: 'medio',   nombre: 'Medium', emoji: '🟡', color: '#E9A100' },
    { id: 'dificil', nombre: 'Hard',   emoji: '🔴', color: '#FF4B4B' }
  ];

  // Acepta los valores nuevos (facil/medio/dificil) y los antiguos
  // guardados dentro del texto del modo: "(Easy, Verbs)", "(Hard, ...)".
  function normalizarDificultadRanking(valor) {
    const texto = String(valor || '')
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '');

    if (texto.indexOf('facil') !== -1 || texto.indexOf('easy') !== -1) return 'facil';
    if (texto.indexOf('medio') !== -1 || texto.indexOf('medium') !== -1) return 'medio';
    if (texto.indexOf('dificil') !== -1 || texto.indexOf('hard') !== -1) return 'dificil';
    return null;
  }

  function dificultadDeRegistro(registro) {
    if (!registro) return null;
    return normalizarDificultadRanking(registro.dificultad) ||
           normalizarDificultadRanking(registro.modo);
  }

  function nombreDificultadRanking(id) {
    const nivel = NIVELES_RANKING.find(n => n.id === id);
    return nivel ? nivel.nombre : 'Otro';
  }

  // Nombres de todas las cuentas conocidas en este navegador.
  function usuariosDelRanking() {
    let usuarios = [];
    try {
      const guardados = JSON.parse(localStorage.getItem('usuarios') || '[]');
      if (Array.isArray(guardados)) usuarios = guardados;
    } catch (e) {
      usuarios = [];
    }
    if (usuarios.length === 0 && typeof USUARIOS_POR_DEFECTO !== 'undefined') {
      usuarios = USUARIOS_POR_DEFECTO;
    }

    const nombres = usuarios
      .map(u => (u && u.user ? String(u.user) : ''))
      .filter(Boolean);

    const actual = localStorage.getItem('userActual');
    if (actual && nombres.indexOf(actual) === -1) nombres.push(actual);
    return nombres;
  }

  function numeroRanking(valor) {
    const numero = parseInt(valor, 10);
    return isNaN(numero) || numero < 0 ? 0 : numero;
  }

  // Mejor puntaje de cada usuario en una dificultad.
  // El total y la cantidad de partidas solo sirven para desempatar.
  function obtenerRanking(dificultad) {
    const resultados = [];

    usuariosDelRanking().forEach(usuario => {
      let historial = [];
      try {
        historial = JSON.parse(localStorage.getItem('hist_' + usuario) || '[]');
      } catch (e) {
        historial = [];
      }
      if (!Array.isArray(historial)) return;

      const partidas = historial.filter(h => dificultadDeRegistro(h) === dificultad);
      if (partidas.length === 0) return;

      resultados.push({
        usuario,
        mejor: partidas.reduce((max, h) => Math.max(max, numeroRanking(h.puntaje)), 0),
        total: partidas.reduce((sum, h) => sum + numeroRanking(h.puntaje), 0),
        partidas: partidas.length
      });
    });

    return ordenarRanking(resultados);
  }

  function ordenarRanking(resultados) {
    return resultados.sort((a, b) =>
      b.mejor - a.mejor ||
      b.total - a.total ||
      a.usuario.localeCompare(b.usuario)
    );
  }

  function escaparHtmlRanking(texto) {
    return String(texto).replace(/[&<>"']/g, caracter => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    })[caracter]);
  }

  function htmlRanking() {
    const usuarioActual = localStorage.getItem('userActual');
    let html = '';

    NIVELES_RANKING.forEach(nivel => {
      const lista = obtenerRanking(nivel.id);

      html += '<div style="margin-bottom:22px;">';
      html += '<h3 style="margin:0 0 8px; color:#1B1035; font-size:1.05rem;">' +
              nivel.emoji + ' ' + nivel.nombre + '</h3>';

      if (lista.length === 0) {
        html += '<p style="background:#f5f5f5; border-radius:12px; padding:14px; color:#777; font-size:14px; margin:0;">' +
                '📭 Todavía no hay partidas en este nivel.</p>';
      } else {
        lista.forEach((entry, index) => {
          const medalla = ['🥇', '🥈', '🥉'][index] || (index + 1);
          const esActual = entry.usuario === usuarioActual;
          html += '<div style="display:flex; align-items:center; gap:10px; padding:10px 12px; margin-bottom:8px; border-radius:12px; ' +
                  'background:' + (esActual ? '#E8F5E9' : '#f5f5f5') + '; border-left:4px solid ' + nivel.color + ';">';
          html += '<span style="font-size:1.2rem; width:28px; text-align:center;">' + medalla + '</span>';
          html += '<div style="flex:1; min-width:0;">';
          html += '<div style="font-weight:bold; color:#1B1035; overflow-wrap:anywhere;">' +
                  escaparHtmlRanking(entry.usuario) + (esActual ? ' <span style="color:#58CC02;">(tú)</span>' : '') + '</div>';
          html += '<div style="font-size:0.78rem; color:#777;">' + entry.partidas +
                  (entry.partidas === 1 ? ' partida' : ' partidas') + ' · ' + entry.total + ' pts acumulados</div>';
          html += '</div>';
          html += '<span style="color:' + nivel.color + '; font-weight:bold; white-space:nowrap;">⭐ ' + entry.mejor + '</span>';
          html += '</div>';
        });
      }
      html += '</div>';
    });

    html += '<p style="color:#999; font-size:12px; text-align:center; margin:0;">' +
            'Ranking por dificultad · Mejor puntaje de cada usuario.</p>';
    return html;
  }

  function verRanking() {
    const pantalla = document.getElementById('pantallaRanking');
    if (!pantalla) return;
    document.getElementById('listaRanking').innerHTML = htmlRanking();
    pantalla.classList.remove('oculto');
    pantalla.style.display = 'flex';
    pantalla.onclick = function (evento) {
      if (evento.target === pantalla) cerrarRanking();
    };
  }

  function cerrarRanking() {
    const pantalla = document.getElementById('pantallaRanking');
    if (!pantalla) return;
    pantalla.classList.add('oculto');
    pantalla.style.display = 'none';
  }
