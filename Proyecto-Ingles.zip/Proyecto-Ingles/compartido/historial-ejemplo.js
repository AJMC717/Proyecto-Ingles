/* ============================================================
   historial-ejemplo.js
   Datos de ejemplo para la presentación: llena hist_<usuario> con
   las mismas partidas que muestra el ranking, para que "Ver mi
   historial" y el ranking lean exactamente los mismos registros.

   Solo se siembra si el usuario aún no tiene datos de ejemplo;
   las partidas reales nunca se borran ni se sobrescriben.
   ============================================================ */

  (function () {
    const PREFIJO_ID = 'ejemplo_';

    const EJEMPLOS = {
      Jhojan: [
        { dificultad: 'facil',   puntaje: 80, modo: 'Write the word (Easy, Verbs)' },
        { dificultad: 'facil',   puntaje: 70, modo: 'Write the word (Easy, Verbs)' },
        { dificultad: 'medio',   puntaje: 60, modo: 'Build sentences (Medium)' },
        { dificultad: 'dificil', puntaje: 30, modo: 'Questions & Answers (Hard)' }
      ],
      Erick: [
        { dificultad: 'facil',   puntaje: 90, modo: 'Write the word (Easy, Verbs)' },
        { dificultad: 'facil',   puntaje: 85, modo: 'Write the word (Easy, Verbs)' },
        { dificultad: 'medio',   puntaje: 75, modo: 'Build sentences (Medium)' },
        { dificultad: 'dificil', puntaje: 45, modo: 'Questions & Answers (Hard)' },
        { dificultad: 'dificil', puntaje: 40, modo: 'Questions & Answers (Hard)' }
      ],
      Dennis: [
        { dificultad: 'facil',   puntaje: 70, modo: 'Write the word (Easy, Verbs)' },
        { dificultad: 'medio',   puntaje: 85, modo: 'Build sentences (Medium)' },
        { dificultad: 'medio',   puntaje: 80, modo: 'Build sentences (Medium)' },
        { dificultad: 'dificil', puntaje: 60, modo: 'Questions & Answers (Hard)' }
      ],
      Belen: [
        { dificultad: 'facil',   puntaje: 95, modo: 'Write the word (Easy, Verbs)' },
        { dificultad: 'medio',   puntaje: 65, modo: 'Build sentences (Medium)' },
        { dificultad: 'medio',   puntaje: 60, modo: 'Build sentences (Medium)' },
        { dificultad: 'dificil', puntaje: 50, modo: 'Questions & Answers (Hard)' }
      ],
      Adriel: [
        { dificultad: 'facil',   puntaje: 60, modo: 'Write the word (Easy, Verbs)' },
        { dificultad: 'medio',   puntaje: 55, modo: 'Build sentences (Medium)' },
        { dificultad: 'dificil', puntaje: 80, modo: 'Questions & Answers (Hard)' },
        { dificultad: 'dificil', puntaje: 75, modo: 'Questions & Answers (Hard)' }
      ]
    };

    Object.keys(EJEMPLOS).forEach((usuario, indiceUsuario) => {
      const clave = 'hist_' + usuario;
      let historial = [];
      try {
        historial = JSON.parse(localStorage.getItem(clave) || '[]');
      } catch (e) {
        historial = [];
      }
      if (!Array.isArray(historial)) historial = [];

      // Ya se sembró antes: no duplicamos.
      if (historial.some(registro => registro && String(registro.id || '').indexOf(PREFIJO_ID) === 0)) {
        return;
      }

      EJEMPLOS[usuario].forEach((entrada, indice) => {
        const minuto = String((indice * 7) % 60).padStart(2, '0');
        historial.push({
          id: PREFIJO_ID + usuario.toLowerCase() + '_' + indice,
          fecha: (15 + indice) + '/11/2026 ' + (9 + indiceUsuario) + ':' + minuto,
          modo: entrada.modo,
          dificultad: entrada.dificultad,
          puntaje: entrada.puntaje,
          rachaMaxima: Math.max(1, Math.round(entrada.puntaje / 10)),
          ejemplo: true
        });
      });

      try {
        localStorage.setItem(clave, JSON.stringify(historial));
      } catch (e) {
        /* almacenamiento lleno o bloqueado: la app sigue funcionando */
      }
    });
  })();
